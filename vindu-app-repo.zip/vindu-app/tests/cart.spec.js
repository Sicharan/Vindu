const { test, expect } = require('@playwright/test');
const { openApp, openMenu, addDish } = require('./helpers');

test.describe('Cart', () => {
  test.beforeEach(async ({ page }) => openApp(page));

  test('adding a dish shows the cart bar with count and total', async ({ page }) => {
    await openMenu(page, 'Smoke');
    await expect(page.locator('.bar')).toHaveCount(0);
    await addDish(page, 'Charred burger');
    await expect(page.locator('.bar')).toContainText('1 item');
  });

  test('quantity can be increased and decreased', async ({ page }) => {
    await openMenu(page, 'Smoke');
    await addDish(page, 'Charred burger');
    const burger = page.locator('.item', { hasText: 'Charred burger' });
    await burger.getByRole('button', { name: 'Add one' }).click();
    await expect(page.locator('.bar')).toContainText('2 items');
    await burger.getByRole('button', { name: 'Remove one' }).click();
    await expect(page.locator('.bar')).toContainText('1 item');
  });

  test('removing the last dish hides the cart bar', async ({ page }) => {
    await openMenu(page, 'Smoke');
    await addDish(page, 'Sesame fries');
    await page.getByRole('button', { name: 'Remove one' }).click();
    await expect(page.locator('.bar')).toHaveCount(0);
  });

  test('adding from another restaurant starts a fresh cart', async ({ page }) => {
    await openMenu(page, 'Smoke');
    await addDish(page, 'Charred burger');
    await page.getByRole('button', { name: 'Back' }).click();
    await openMenu(page, 'Bao Bar');
    await addDish(page, 'Chili noodles');
    await expect(page.locator('.bar')).toContainText('1 item');
    await page.locator('.bar').click();
    await expect(page.locator('.box', { hasText: 'Bao Bar' })).toBeVisible();
    await expect(page.getByText('Charred burger')).toHaveCount(0);
  });

  test('empty cart shows guidance instead of a checkout form', async ({ page }) => {
    await page.evaluate(() => go('checkout'));
    await expect(page.getByText('Your cart is empty')).toBeVisible();
    await expect(page.getByRole('button', { name: /Place order/ })).toHaveCount(0);
  });
});
