const { test, expect } = require('@playwright/test');
const { openApp, openMenu, addDish } = require('./helpers');

async function cartWithTwoBurgers(page) {
  await openMenu(page, 'Smoke');
  await addDish(page, 'Charred burger');
  await page.locator('.item', { hasText: 'Charred burger' }).getByRole('button', { name: 'Add one' }).click();
  await page.locator('.bar').click();
}

test.describe('Checkout and pricing', () => {
  test.beforeEach(async ({ page }) => openApp(page));

  test('bill adds up: subtotal + delivery fee + 5% GST', async ({ page }) => {
    await cartWithTwoBurgers(page); // 2 x 249 = 498, fee 30, GST 24.90
    const bill = page.locator('.box').filter({ hasText: 'Subtotal' });
    await expect(bill.locator('.row', { hasText: 'Subtotal' })).toContainText('₹498');
    await expect(bill.locator('.row', { hasText: 'Delivery fee' })).toContainText('₹30');
    await expect(bill.locator('.row', { hasText: 'GST' })).toContainText('₹24.90');
    await expect(bill.locator('.total')).toContainText('₹552.90');
  });

  test('payment method can be changed', async ({ page }) => {
    await cartWithTwoBurgers(page);
    await page.getByLabel('Cash on delivery').check();
    await expect(page.getByLabel('Cash on delivery')).toBeChecked();
    await expect(page.getByLabel('Card', { exact: true })).not.toBeChecked();
  });

  test('delivery address is editable and carried to tracking', async ({ page }) => {
    await cartWithTwoBurgers(page);
    await page.getByLabel('Delivery address').fill('7 Lake View Road');
    await page.getByRole('button', { name: /Place order/ }).click();
    await expect(page.getByText('7 Lake View Road')).toBeVisible();
  });
});

test.describe('Order tracking', () => {
  test('order moves from placed to delivered', async ({ page }) => {
    await openApp(page);
    await cartWithTwoBurgers(page);
    await page.getByRole('button', { name: /Place order/ }).click();

    await expect(page.getByRole('heading', { name: 'Your order is on its way' })).toBeVisible();
    await expect(page.locator('.steps li.done')).toHaveCount(1);

    await page.clock.fastForward(4000);
    await expect(page.locator('.steps li.done')).toHaveCount(2);

    await page.clock.fastForward(8000);
    await expect(page.locator('.steps li.done')).toHaveCount(4);
    await expect(page.getByRole('heading', { name: 'Enjoy your meal!' })).toBeVisible();
  });

  test('cart is cleared after placing an order', async ({ page }) => {
    await openApp(page);
    await cartWithTwoBurgers(page);
    await page.getByRole('button', { name: /Place order/ }).click();
    await page.getByRole('button', { name: 'Back to restaurants' }).click();
    await expect(page.locator('.bar')).toHaveCount(0);
  });
});
