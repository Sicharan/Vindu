const path = require('path');

// Point APP_URL at a deployed link to test that instead of the local file.
const APP_URL =
  process.env.APP_URL || 'file://' + path.resolve(__dirname, '../app/index.html');

// Opens the app with a controllable clock so order-tracking timers can be fast-forwarded.
async function openApp(page) {
  await page.route('**/fonts.googleapis.com/**', (r) => r.abort());
  await page.clock.install();
  await page.goto(APP_URL, { waitUntil: 'domcontentloaded' });
}

async function openMenu(page, restaurant) {
  await page.locator('.rest', { hasText: restaurant }).click();
}

async function addDish(page, dish) {
  await page.locator('.item', { hasText: dish }).getByRole('button', { name: 'Add', exact: true }).click();
}

module.exports = { openApp, openMenu, addDish };
