const { test, expect } = require('@playwright/test');
const { openApp } = require('./helpers');

test.describe('Browsing restaurants', () => {
  test.beforeEach(async ({ page }) => openApp(page));

  test('home screen lists all restaurants', async ({ page }) => {
    await expect(page.getByText('What are you craving?')).toBeVisible();
    await expect(page.locator('.rest')).toHaveCount(5);
  });

  test('search filters restaurants by name', async ({ page }) => {
    await page.getByLabel('Search').fill('bao');
    await expect(page.locator('.rest')).toHaveCount(1);
    await expect(page.locator('.rest')).toContainText('Bao Bar');
  });

  test('category chip filters restaurants', async ({ page }) => {
    await page.getByRole('button', { name: 'Pizza', exact: true }).click();
    await expect(page.locator('.rest')).toHaveCount(1);
    await expect(page.locator('.rest')).toContainText('Slice Society');
  });

  test('shows a helpful message when nothing matches', async ({ page }) => {
    await page.getByLabel('Search').fill('zzzz');
    await expect(page.getByText('No restaurants match')).toBeVisible();
  });

  test('opens a menu and goes back', async ({ page }) => {
    await page.locator('.rest', { hasText: 'Tandoor Lane' }).click();
    await expect(page.getByRole('heading', { name: 'Tandoor Lane' })).toBeVisible();
    await expect(page.locator('.item')).toHaveCount(4);
    await page.getByRole('button', { name: 'Back' }).click();
    await expect(page.getByText('What are you craving?')).toBeVisible();
  });
});
