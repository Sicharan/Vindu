# Vindu app – automated tests (Playwright)

## One-time setup
1. Install Node.js (v18+) from https://nodejs.org
2. In this folder run:
   npm install
   npx playwright install chromium

## Run the tests
   npm test            # runs all tests on desktop Chrome and a Pixel 5 phone profile
   npm run test:ui     # opens Playwright's visual test runner
   npm run report      # opens the HTML report of the last run

## Test a deployed link instead of the local file
   APP_URL="https://your-link" npm test        (Mac/Linux)
   set APP_URL=https://your-link && npm test   (Windows)

## What is covered (15 tests x 2 devices)
- Browsing: list, search, category filter, empty state, open menu / back
- Cart: add, increase, decrease, remove, switching restaurants, empty cart
- Checkout: bill maths (subtotal, delivery fee, 5% GST, total), payment choice, address
- Order tracking: placed -> preparing -> out for delivery -> delivered, cart cleared
